const couponTab = document.querySelector('.coupon-tab');
const couponContainer = document.querySelector('.coupon-container');
const couponCloseBtn = document.querySelector('.coupon-close');

couponTab.addEventListener('click', () => {
  couponContainer.style.display = 'block';
});

couponCloseBtn.addEventListener('click', () => {
  couponContainer.style.display = 'none';
});

const removeItemBtns = document.querySelectorAll('.remove-item-btn');

removeItemBtns.forEach((btn) => {
  btn.addEventListener('click', () => {t
    console.log('Item removed');
  });
});

function confirmPayment(paymentMethod) {
  const creditCardForm = document.getElementById('credit-card-form');
  const debitCardForm = document.getElementById('debit-card-form');
  const pixForm = document.getElementById('pix-form');
  
  if (paymentMethod === 'credit-card') {
    creditCardForm.style.display = 'block';
    debitCardForm.style.display = 'none';
    pixForm.style.display = 'none';
  } else if (paymentMethod === 'debit-card') {
    creditCardForm.style.display = 'none';
    debitCardForm.style.display = 'block';
    pixForm.style.display = 'none';
  } else if (paymentMethod === 'pix') {
    creditCardForm.style.display = 'none';
    debitCardForm.style.display = 'none';
    pixForm.style.display = 'block';
  }
}

function finalizePurchase() {
}